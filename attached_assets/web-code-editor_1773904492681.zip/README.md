# WebCode Studio

A VS Code-inspired web IDE with Monaco editor, multi-file project support, browser preview, and sandboxed JavaScript execution.

## Features

- Multi-file explorer for `.html`, `.css`, and `.js`
- File tabs and Monaco editor with syntax highlighting and IntelliSense-like suggestions
- Auto-closing tags/brackets and format action
- `Run All` for HTML + CSS + JS preview in iframe
- `Run JS Only` and `Run Node Cmd` (`node <file.js>`) using backend sandbox
- Console panel for logs, warnings, and errors
- Dark/light theme
- Resizable sidebar, editor/preview split, and console panel
- Save/load via local storage
- Download project as ZIP

## Local Development

1. Install dependencies:

```bash
npm install
```

2. Start frontend dev server:

```bash
npm run dev
```

3. Start backend sandbox server in a second terminal:

```bash
node server/index.js
```

4. Open the frontend URL shown by Vite.

Optional: set API base URL in frontend (for custom backend host):

```bash
VITE_API_BASE_URL=http://localhost:4000
```

## Deploy On Render (Single Service)

This repo includes `render.yaml` for one Node web service:

- Build Command: `npm install && npm run build`
- Start Command: `node server/index.js`

The Express server automatically serves the built frontend from `dist` and exposes API routes under `/api`.

### Steps

1. Push this project to GitHub.
2. In Render, create a new Blueprint deployment from your repo.
3. Render reads `render.yaml` and provisions the service.
4. Open the deployed URL.

No separate frontend/backend service is required for this setup.